SBL 1.0 resolved page rendering package
Render target: CH2-P022
Entry file: CH2-P022.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zora-cultural-development-specification.txt
  Assets/Zora-Nyas-world-map.png
  Assets/Zora-mana-effects-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
