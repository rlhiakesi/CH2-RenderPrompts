SBL 1.0 resolved page rendering package
Render target: CH2-P049
Entry file: CH2-P049.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/WOA-canonical-production-specification.txt
  Assets/Terra-canonical-character-specification.txt
  Assets/Nyssara-expression-sheet.png
  Assets/WOA-production-sheet.png
  Assets/WOA-observation-field-states-sheet.png
  Assets/Terra-character-sheet.png
  Assets/Terra-expression-sheet.png
  Assets/Zora-Nyas-world-map.png
  Assets/Nyas-cultural-development-specification.txt
  Assets/Nyssara-character-sheet.png
  Assets/Nyssara-canonical-character-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
