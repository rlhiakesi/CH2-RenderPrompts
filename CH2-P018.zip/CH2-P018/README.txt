SBL 1.0 resolved page rendering package
Render target: CH2-P018
Entry file: CH2-P018.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zora-Nyas-writing-systems-renderer-spec.txt
  Assets/Zora-Nyas-world-map.png
  Assets/Zora-Nyas-writing-systems-sheet.png
  Assets/Nyassarian_Language_and_Script.docx

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
