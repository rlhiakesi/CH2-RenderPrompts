SBL 1.0 resolved page rendering package
Render target: CH2-P036
Entry file: CH2-P036.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Nyssara-expression-sheet.png
  Assets/Zorna-canonical-character-specification.txt
  Assets/Nyssara-canonical-character-specification.txt
  Assets/Zorna-expression-sheet.png
  Assets/Zora-Nyas-world-map.png
  Assets/Zorna-character-sheet.png
  Assets/Zora-cultural-development-specification.txt
  Assets/Nyssara-character-sheet.png
  Assets/WOA-canonical-production-specification.txt
  Assets/WOA-observation-field-states-sheet.png
  Assets/WOA-production-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
