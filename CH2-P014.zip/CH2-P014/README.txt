SBL 1.0 resolved page rendering package
Render target: CH2-P014
Entry file: CH2-P014.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zorna-canonical-character-specification.txt
  Assets/Terra-character-sheet.png
  Assets/Zorna-character-sheet.png
  Assets/WOA-canonical-production-specification.txt
  Assets/WOA-production-sheet.png
  Assets/Nyssara-character-sheet.png
  Assets/Zorna-expression-sheet.png
  Assets/Terra-expression-sheet.png
  Assets/Terra-canonical-character-specification.txt
  Assets/Nyssara-expression-sheet.png
  Assets/Nyssara-canonical-character-specification.txt
  Assets/Zora-cultural-development-specification.txt
  Assets/WOA-observation-field-states-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
