SBL 1.0 resolved page rendering package
Render target: CH2-P021
Entry file: CH2-P021.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zorna-character-sheet.png
  Assets/Zora-cultural-development-specification.txt
  Assets/Zora-mana-effects-sheet.png
  Assets/WOA-production-sheet.png
  Assets/WOA-canonical-production-specification.txt
  Assets/Zora-Nyas-world-map.png
  Assets/WOA-observation-field-states-sheet.png
  Assets/Zorna-canonical-character-specification.txt
  Assets/Zorna-expression-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
